<?php 

function portfolio_files() {
    wp_enqueue_style("custom_google_fonts", "https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap");
    wp_enqueue_style("black_900", 'https://fonts.googleapis.com/css2?family=Maven+Pro:wght@900&display=swap');
    wp_enqueue_style("custom_google_fonts",'https://fonts.googleapis.com/css2?family=Asap:wght@600&family=Maven+Pro:wght@900&display=swap');
    wp_enqueue_style("portfolio_social_styles", "https://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css");
    wp_enqueue_style("portfolio_main_styles", get_stylesheet_uri());
}

add_action("wp_enqueue_scripts", "portfolio_files");

function portfolio_features() {
    add_theme_support("title-tag");
}

add_action("after_setup_theme", "portfolio_features")

?>