<!DOCTYPE html>
<html>
    <head>
           <!-- Include Font Awesome Stylesheet in Header -->
   <link href= rel="stylesheet">
        <?php wp_head() ?>
    </head>

    <body>
        <header>
    
                <ul class = "name_link">
                <li><a>SAM</a></li>
                <li><a>STAMP</a></li>
                </ul>
                <nav>
                    <ul class="nav__links">
                    <?php wp_nav_menu( array('menu' => 'Main', 'container' => 'nav' )); ?>
                    </ul>
                </nav>
        
            

        </header> 



