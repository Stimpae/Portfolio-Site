<?php wp_footer(); ?>

<footer>
    <div class="container_footer">
        <div class="primary_footer">
            <div class="grid-container">
                <div class="col1">
                    <h2> Column One </h2>
                </div>
                <div class="col2">
                    <h2> Column Two</h2>
                </div>
                <div class="col3">
                    <h2> Column Three</h2>
                </div>
                <div class="social">
                    <div class="lab_social_icon_footer">
                            <a href="https://www.facebook.com/bootsnipp"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
                            <a href="https://twitter.com/bootsnipp"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
                            <a href="https://plus.google.com/+Bootsnipp-page"><i id="social-gp" class="fa fa-github-square fa-3x social"></i></a>
                            <a href="mailto:#"><i id="social-em" class="fa fa-linkedin-square fa-3x social"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="secondary_footer">
            <p class="copyright-text">Copyright &copy; 2020 All Rights Reserved by
                <a href="#">Sam Stamp</a>.
        </div>
    </div>
</footer>

</body>

</html>
